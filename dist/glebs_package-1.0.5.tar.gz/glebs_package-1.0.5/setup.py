from setuptools import setup, find_packages

setup(
    name="glebs_package",
    version="1.0.5",
    packages=find_packages(),
    install_requires=[],  # Add dependencies if needed
    python_requires=">=3.7",
)
