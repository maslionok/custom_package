from .langident import langident_pipeline
from .ocrqa import ocrqa_pipeline
